Upload icon files to the website root. Add inside <head>:
<link rel="apple-touch-icon" href="./apple-touch-icon.png">
<link rel="icon" href="./favicon.ico">
<link rel="manifest" href="./manifest.webmanifest">
